<?php 
include_once 'php/connector.php';

$return = $_POST;

// Implementing them
if (isset($_POST["name"])) {
	# code...
	$return["type"] = "signup";

	$name = $_POST["name"];
	$email = $_POST["email"];
	$number = $_POST["number"];
	$password = $_POST["password"];

	$sql = "SELECT * FROM users WHERE email = '".$email."' ";
	$result = mysqli_query($con, $sql);

	if (mysqli_num_rows($result) > 0) {
		# code...
		$return["result"] = " was a <code>failure</code>. Email already in use!";
	} else {
		$sql = "INSERT INTO users(name, email, phone, password, r_date) VALUES ('".$name."','".$email."', '".$number."','".$password."',NOW())";
	if ($result = mysqli_query($con, $sql)) {
		# code...
		$return["result"] = " was a <code>success</code>. Login to create a session";
	} else {
		$return["result"] = " was a <code>failure</code>.";
	}
	}
} else {
	$return["type"] = "login";

	$email = $_POST["username"];
	$password = $_POST["pwd"];

	$sql = "SELECT id FROM users WHERE email = '".$email."'";
	$result = mysqli_query($con, $sql);
	if (mysqli_num_rows($result) > 0) {
		# code...
		$sql = "SELECT id, name, email, phone FROM users WHERE email = '".$email."' AND password = '".$password."'";
		$result = mysqli_query($con, $sql);
		if (mysqli_num_rows($result) > 0) {
		# code...
			$row = mysqli_fetch_array($result);
			session_start();
			$_SESSION["user_id"] = $row["id"];
			$_SESSION["user_name"] = $row["name"];
			$_SESSION["user_email"] = $row["email"];
			$_SESSION["user_phone"] = $row["phone"];

			$return["result"] = " was a <code>success</code>. Logged in as <strong>".$_SESSION["user_name"]."</strong> <a href='vehicles.php'><code>Proceed to vehicles?</code></a>.";
		} else {
			$return["result"] = " was a <code>failure</code>. Wrong Password!";
		}
	} else {
		$return["result"] = " was a <code>failure</code>. User does not exist! Consider signing up.";
	}
}

$return["response"] = json_encode($return);

echo json_encode($return);
?>