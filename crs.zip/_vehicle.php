<?php 
// echo "We got you " . $_POST["name"];
if (is_ajax()) {
	if (isset($_POST["car"]) && !empty($_POST["car"])) { 
		//Checks if car value exists
		$car = $_POST["car"];
		test_function();
	}
}

//Function to check if the request is an AJAX request
function is_ajax() {
	return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}
function test_function(){
	include_once 'php/connector.php';

	// Preparing form data for return to jquery
	$return = $_POST;

	$days = " + " . $_POST["days"] . " days";

	$return["json"] = json_encode($return);

	$amount = $_POST["days"] * $_POST["cost"];
	$return["cost"] = $amount;

	$r_date = $_POST["date"];

	$f_date = date("Y/m/d", strtotime($r_date. $days));

	$r_date = date_format(date_create($r_date), "l d F, Y");
	$f_date = date_format(date_create($f_date), "l d F, Y");

	$return["from_date"] = $r_date;
	$return["to_date"] = $f_date;

	session_start();
	$user_id = $_SESSION["user_id"];
	$car_id = $_POST["car"];
	$days = $_POST["days"];
	$message = $_POST["message"];

	$sql = "INSERT INTO tbl_rent(user_id, car_id, r_date, r_days, amount, message) VALUES('".$user_id."', '".$car_id."', NOW(), '".$days."', '".$amount."', '".$message."')";
	if ($result = mysqli_query($con, $sql)) {
		$return["result"] = "<strong>We have received your request. We'll get back to you!</strong>";
	} else {
		$return["result"] = "Failed to submit request. Please try again!" . mysqli_error($con);
	}
	echo json_encode($return);
}
?>