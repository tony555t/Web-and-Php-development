<!DOCTYPE html>
<html>
<head>
	<title>Vehicles</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<meta name= "description" content="affordable car">
	<meta name="keywords" content="affordable cars">
	<meta name="author" content="Namsi Lydia">
	<!-- Bootstrap -->
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- JS Files -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<header>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
			<div class="container">
				<a class="navbar-brand pull-left" href="#"><strong>Car Rental System</strong></a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item">
							<a class="nav-link" href="index.php"><strong>Home</strong>
								<span class="sr-only">(current)</span>
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="about.html"><strong>About</strong></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="vehicles.php"><strong>Vehicles</strong></a>
						</li>
						<?php 
						session_start();
						if (isset($_SESSION["user_name"])) {
              # code...
							echo '
							<li class="nav-item active"><a class="nav-link" href="#"><span class="glyphicon glyphicon-user"></span><strong>&nbsp;&nbsp;'.$_SESSION["user_name"].', Logout.</strong></a></li>
							';
						} else {
							echo '
							<li class="nav-item active"><a class="nav-link" href="#"><span class="glyphicon glyphicon-log-in"></span> <strong>Login</strong></a></li>
							';
						}
						?>
					</ul>
				</div>
			</div>
		</nav>
	</header>

	<!-- The Vehicles Section -->
	<div class="container" style="margin-top: 5em;">
		<div class="row">
			<div class="col-md-2 col-sm-1 col-xs-0">

			</div>
			<div class="col-md-8 col-sm-10 col-xs-12">
				<?php if (isset($_GET["task"]) && $_GET["task"] == "signout" ) {
					# code...
					// session_start();
					if (isset($_SESSION)) {
					# code...
					// remove all session variables
						session_unset(); 

					// destroy the session 	
						session_destroy();
						echo '<ul><li class="list-group-item">You\'ve been signed out!</li></ul>';
					}
				} ?>
				<ul class="nav nav-tabs">
					<li class="btn-login active"><a href="#">Login</a></li>
					<li class="btn-signup"><a href="#">Sign-Up</a></li>
				</ul>
				<div class="list-group">

					<div class="list-group-item form-login">
						<h3 style="width: 100%; text-align: center;">Enter your credentials.</h3>
						<hr>
						<form class="form-horizontal" id="login-form" action="/action_page.php">
							<div class="form-group">
								<label class="control-label col-sm-2" for="email">Email:</label>
								<div class="col-sm-10">
									<input type="email" required name="username" class="form-control" id="email" placeholder="Enter email">
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2" for="pwd">Password:</label>
								<div class="col-sm-10"> 
									<input type="password" required name="pwd" class="form-control" id="pwd" placeholder="Enter password">
								</div>
							</div>
							<div class="form-group"> 
								<div class="col-sm-offset-2 col-sm-10">
									<div class="checkbox">
										<label><input type="checkbox"> Remember me</label>
									</div>
								</div>
							</div>
							<div class="form-group"> 
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" name="login" class="btn btn-success">Login</button>
								</div>
							</div>
						</form>
					</div>
					<div class="list-group-item form-signup" style="display: none;">
						<h3 style="width: 100%; text-align: center;">Enter your details.</h3>
						<hr>
						<form class="form-horizontal" id="signup-form" action="/action_page.php">
							<div class="form-group">
								<label class="control-label col-sm-2" for="name">Name:</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="name" required id="name" placeholder="Full Name">
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2" for="email">Email:</label>
								<div class="col-sm-10">
									<input type="email" name="email" required class="form-control" id="email" placeholder="Email Address">
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2" for="email">Phone:</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" required name="number" id="number" placeholder="Phone Number">
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2" for="pwd">Password:</label>
								<div class="col-sm-10"> 
									<input type="password" name="password" required class="form-control" id="pwd" placeholder="Type your password">
								</div>
							</div>
							<div class="form-group"> 
								<div class="col-sm-offset-2 col-sm-10">
									<div class="checkbox">
										<label><input type="checkbox"> Remember me</label>
									</div>
								</div>
							</div>
							<div class="form-group"> 
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" name="signup" class="btn btn-danger">Register</button>
								</div>
							</div>
						</form>
					</div>
					<div class="list-group-item response-bar form-group" style="display: none; text-align: center;">
						<a href="vehicles.php">Proceed to Vehicles...</a>
					</div>
				</div>
			</div>
			<div class="col-md-2 col-sm-1 col-xs-0">

			</div>
		</div>
	</div>
	<!-- close container -->
	<hr>

	<script src="js/custom.js"></script>
	<script type="text/javascript">
		var split = location.search.replace('?', '').split('=');
		// alert("We haave " + split[1]);
		if (split[1] == "signup") {
			// alert("Almost there");
			$(".btn-signup").click();
		} else {
			// alert("Of course");
		}

		$(".login").on('click', function (e) {
			// body...
			e.preventDefault();
			$(".btn-login").click();
		});

		$(".signup").on('click', function (e) {
			// body...
			e.preventDefault();
			$(".btn-signup").click();
		});
	</script>

</body>
</html>