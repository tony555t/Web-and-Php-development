<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width">
 <meta name= "description" content="affordable car">
 <meta name="keywords" content="affordable cars">
 <meta name="author" content="Namsi Lydia">
 <title>CAR RENTAL SYSTEM</title>
 <!-- Bootstrap -->
 <!-- Latest compiled and minified CSS -->
 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
 <!-- jQuery library -->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <!-- Latest compiled JavaScript -->
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 <!-- JS Files -->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" type="text/css" href="css/style.css">
 <link href="css/half-slider.css" rel="stylesheet">
</head>
<body>
  <!-- Start of nav section -->
  <section>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand pull-left" href="#"><strong>Car Rental System</strong></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse pull-right" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link active" href="#"><strong>Home</strong>
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.html"><strong>About</strong></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="vehicles.php"><strong>Vehicles</strong></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><span class="glyphicon glyphicon-log-in"></span> <strong>Login</strong></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </section>
  <!-- End of nav section -->
  <!-- Start of slideshow -->
  <section>
    <header>
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <!-- <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li> -->
          <?php 
          include_once 'php/connector.php';
          // echo "Mambo poa";
          $sql = "SELECT id FROM vehicles ORDER BY rand() LIMIT 5";
          $result = mysqli_query($con, $sql);
          $active = "active";
          while ($row = mysqli_fetch_array($result)) {
            # code...
            echo '<li data-target="#carouselExampleIndicators" data-slide-to="'.$row["id"].'" class="'.$active.'"></li>';
            $active = "";
          }
          ?>
        </ol>
        <div class="carousel-inner" role="listbox">
          <!-- Slide One - Set the background image for this slide in the line below -->

          <?php 
          $sql = "SELECT * FROM vehicles ORDER BY rand() LIMIT 5";
          $result = mysqli_query($con, $sql);
          // echo "ACTIVE STRING " .$active;
          $active = "active";
          while ($row = mysqli_fetch_array($result)) {
            # code...
            echo '
            <div class="carousel-item '.$active.'"<!--style="background-image: url('.str_replace(" ", "", $row["image"]).')"-->>
            <img src="'.str_replace(" ", "", $row["image"]).'">
            <div class="carousel-caption d-none d-md-block">
            <h3>'.$row["name"].'</h3>
            <p>'.$row["description"].'</p>
            </div>
            </div>
            ';

            $active = "";
          }
          ?>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </header>
  </section>
  <!-- End of slideshow -->
  <!-- Start of jumbotron -->
  <div style="/*background: rgba(23,23,23,0.5); */background: url('img/demo/rangeroverevogue.jpg') no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;">
  <section class="well">
    <div class="row">
      <div class="jumbotron" style="opacity: 0.9; text-align: center; padding-left: 10em; padding-right: 10em;">
        <h2><strong>Car Rental System</strong></h2>
        <hr>
        <P>Car rental system is a car booking software that provides a complete solution to all your day-to-day car booking office running needs. This system helps you to keep the information of Customer online. You can check your customer information any time by using this system. Car rental management system is a unique and innovative product. 
          This aim of the system is to automate the work performed in the car rental management system like generating daily bookings, records of car or cab available for booking, record of routes available, rental charges for cars for every route, store record of the customer. 
        </P>
      </div>
    </div>
  </section>
  <section style="opacity: 0.8;">
    <div class="container">
      <div>
        <div class="jumbotron">
          <div class="col-md-6">
            <h3><strong>Get Our Periodic Newsletter</strong></h3>
            <hr>
          </div>
          <div class="col-md-6" style="">
            <form class="form-inline" action="#">
              <div class="form-group">
                <input type="email" name="email" placeholder="Email Address" class="form-control" id="email">
              </div>
              &nbsp;&nbsp;&nbsp;
              <button type="submit" class="btn btn-default" style="background: #e8491d; border-radius: 0; color: white;"> <strong>Subscribe</strong> </button>
            </form>
          </div>            
        </div>
        <div class="row">
          <div class="col-md-8">
            <div class="jumbotron">
              <h2><strong>About Us</strong></h2>
              <hr>
              <P>
                This is a car rental company website where the customers can get the best quality services without stress.we easen your work by showing your the available cars around that you can rent out to help you with your personal transportation needs.this website offers cars to the customer at a cost where the user selects the particular ride they want and rent it out.cost vary according to the particular ride that you choose.
              </P>
            </div>
          </div>
          <div class="col-md-4">
            <div class="jumbotron" style="background: #e8491d; color: white;">
              <h3><strong>What we do</strong></h3>
              <hr>
              <p>We easen your transportation needs and make sure you get quality services that are worth your money.</p>
            </div>

          </div>
        </div>
      </div>
    </section>
    <section style="opacity: 0.8;">
      <div class="container">
        <div class="jumbotron">
          <h3><strong>Vision</strong></h3>
          <hr>
          <p>  Grow your brand by initiating good prices and good customer care and ensure that every facility is up to task and offers standard services services</p>
        </div>
      </div>
    </section>
  </div>
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

