var car = "Car1";
var cost = 1000;
$(".btn-rent").on('click', function (e) {
  e.preventDefault();
  car = $(this).data("car-key");
  cost = $(this).data("car-cost");
  $(".response-holder").empty();
      // alert("We are almost there with car " + car);
      var carDetails = '<table class="table table-bordered">' + $(".car-details-table-" + car).html() + "</table>";
      $(".car-details").html(carDetails);
    });

// New way of doing things
$("document").ready(function(){
  $("#rent-form").submit(function(){
    // var car = $(".btn-rent").data("car-key");
    var data = {
      "car": car,
      "cost": cost
    };
    data = $(this).serialize() + "&" + $.param(data);
    $.ajax({
      type: "POST",
      dataType: "json",
      url: "_vehicle.php",
      data: data,
      success: function(data) {
        $(".response-holder").hide();
        $(".response-holder").html(
          "<code>Start Date</code> : " + 
          data["from_date"] + 
          "<br /><code>End Date</code> : " + 
          data["to_date"] + 
          "<br /><code>Days</code> : " + 
          data["days"] + 
          "<br /><code>Cost</code> : " + 
          data["cost"] + 
          "<br /> <code>Note</code> : " + data["result"]
          );
        $(".response-holder").show();
        // alert("Form submitted successfully.\nReturned json: " + data["json"]);
      },
      error: function (xhr, status, error, data) {
        // body...
        // alert("Error : " + xhr.responseText);
        alert("Oops : " + error);
        // alert("Error 3 : " + data);
      }
    });
    return false;
  });
});


// Animating the viewing of the cars
(function($) {

  'use strict';

  var $filters = $('.filter [data-filter]'),
  $boxes = $('.boxes [data-category]');

  $filters.on('click', function(e) {
    e.preventDefault();
    var $this = $(this);
    
    $filters.removeClass('active');
    $this.addClass('active');

    var $filterColor = $this.attr('data-filter');

    if ($filterColor == 'all') {
      $boxes.removeClass('is-animated')
      .fadeOut().promise().done(function() {
        $boxes.addClass('is-animated').fadeIn();
      });
    } else {
      $boxes.removeClass('is-animated')
      .fadeOut().promise().done(function() {
        $boxes.filter('[data-category = "' + $filterColor + '"]')
        .addClass('is-animated').fadeIn();
      });
    }
  });

})(jQuery);

// Showing and Hiding relevant forms in auth.php
$(".btn-login").on('click', function () {
  // body...
  // alert("You've clicked on the login button");
  $(".response-bar").hide("slow");

  $(this).addClass("active");
  $(".login").addClass("active");
  $(".btn-signup").removeClass("active");
  $(".signup").removeClass("active");

  $(".form-login").show();
  $(".form-signup").hide();

});

$(".btn-signup").on('click', function () {
  // body...
  // alert("You've clicked on the signup button");

  $(this).addClass("active");
  $(".signup").addClass("active");
  $(".btn-login").removeClass("active");
  $(".login").removeClass("active");

  $(".form-signup").show();
  $(".form-login").hide();

  $(".response-bar").hide();

});

$("#login-form, #signup-form").submit(function(){
  var data = {
    "car": car,
    "cost": cost
  };
  data = $(this).serialize();
  $.ajax({
    type: "POST",
    dataType: "json",
    url: "_auth.php",
    data: data,
    success: function(data) {
      // alert("Sucess" + data["username"] + data["pwd"]);
      $(".response-bar").html("The " + data["type"] + " process " + data["result"]);
      $(".response-bar").show("fast");
    },
    error: function (xhr, status, error, data) {
        // body...
        // alert("Error : " + xhr.responseText);
        alert("Oops! : " + error + ". Additionally : " + status);
      }
    });
  return false;
});