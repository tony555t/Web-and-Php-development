<?php

$host = "198.23.61.43";
// $host = "127.0.0.1";

$mysql_username = "afrikinu_mamai";
// $mysql_username = "root";

$mysql_pwd = "MyNaMe_l6s3";
// $mysql_pwd = "";

$db_name = "afrikinu_crs_db";
$con = mysqli_connect($host, $mysql_username, $mysql_pwd, $db_name)  or die("Failed to connect to the database.");
?>