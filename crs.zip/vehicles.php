<!DOCTYPE html>
<html>
<head>
  <title>Vehicles</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <meta name= "description" content="affordable car">
  <meta name="keywords" content="affordable cars">
  <meta name="author" content="Namsi Lydia">
  <!-- Bootstrap -->
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <link rel="stylesheet" type="text/css" href="css/style.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
  <!-- JS Files -->
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
</head>
<body>
  <header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand pull-left" href="#"><strong>Car Rental System</strong></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse pull-right" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php"><strong>Home</strong>
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.html"><strong>About</strong></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="vehicles.php"><strong>Vehicles</strong></a>
            </li>
            <?php 
            session_start();
            if (isset($_SESSION["user_name"])) {
              # code...
              echo '
              <li class="nav-item"><a class="nav-link" href="auth.php?task=signout"><span class="glyphicon glyphicon-user"></span><strong>&nbsp;&nbsp;'.$_SESSION["user_name"].', Logout.</strong></a></li>
              ';
            } else {
              echo '
              <li class="nav-item"><a class="nav-link" href="auth.php?task=login"><span class="glyphicon glyphicon-log-in"></span> <strong>Login</strong></a></li>
              ';
            }
            ?>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <!-- The Vehicles Section -->
  <div class="container" style="margin-top: 5em;">
    <div id="row">
      <div class="row filter" style="padding: 0.6em; display: inline; float: right;">
        <ul class="nav nav-tabs">
          <li class="active">
            <a data-filter="all" href="#all"><strong>All</strong></a>

            <?php 
            include_once 'php/connector.php';
            $sql = "SELECT name, category, image, unit_cost FROM vehicles GROUP BY category";
            $result = mysqli_query($con, $sql) or die("ERROR : " . mysqli_error($con));

            while ($row = mysqli_fetch_array($result)) {
          # code...
          // echo "We have something";
              echo '
              <li class="filter-category"><a data-filter="'.str_replace(" ", "-", $row["category"]).'" href="#'.str_replace(" ", "-", $row["category"]).'"><strong>'.$row["category"].'</strong></a></li>
              ';
            }
            ?>
          </li>
        </ul>
        <!-- </div> -->

        <div class="row boxes">
          <?php 
          $sql = "SELECT * FROM vehicles";
          $result = mysqli_query($con, $sql);

          while ($row = mysqli_fetch_array($result)) {
          # code...
          // echo "We have something";
            if (isset($_SESSION["user_name"])) {
            # code...
              $button = '<a href="#" data-toggle="modal" data-target="#myModal" data-car-key="'.$row["id"].'" data-car-cost="'.$row["unit_cost"].'" class="btn btn-danger btn-rent">Rent Now</a>';
            } else {
              $button = '<a href="auth.php" class="btn btn-danger">Rent Now</a>';
            }
            echo '
            <div class=" col-md-3 col-sm-6 '.str_replace(" ", "-", $row["category"]).'" data-category="'.str_replace(" ", "-", $row["category"]).'">
            <div style="padding:0.1em;" class="panel panel-default">
            <p style="height:9em;"> <a title="" href="'.$row["id"].'"><img class="img-responsive" style="width:100%" src="'.str_replace(" ", "", $row["image"]).'" alt="" width="210" height="145" class="portfolio-img pretty-box"></a> </p>
            <table class="table table-bordered">
            <tbody class="car-details-table-'.$row["id"].'">
            <tr class="warning">
            <td><strong>Name</strong></td>
            <td>'.$row["name"].'</td>
            </tr>
            <tr class="warning">
            <td><strong>Year</strong></td>
            <td>'.$row["m_date"].'</td>
            </tr>
            <tr class="warning">
            <td><strong>Cost</strong></td>
            <td>Ksh '.$row["unit_cost"].'</td>
            </tr>
            </tbody>
            <tbody>
            <tr class="warning">
            <td><a href="#" class="btn btn-primary">More Info</a></td>
            <td>'.$button.'</td>
            </tr>
            </tbody>
            </table>
            </div>
            </div>
            ';
          }
          ?>
          <!--END div-->
        </div>

        <!-- Trigger the modal with a button -->
      </div>
    </div>
    <!-- close container -->
    <script src="js/custom.js"></script>

    <!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title" style="text-align: center;">You have chosen the vehicle below. Please fill in the form then submit.</h4>
          </div>
          <div class="modal-body">
            <div class="col-md-6 col-sm-12">
              <p style="text-align: center;"><strong>Car Details</strong></p>
              <p class="car-details"></p>
            </div>
            <div class="col-md-6 col-sm-12">
              <p style="text-align: center;"><strong>Your Details</strong></p>
              <p>
                <table class="table table-bordered">
                  <tbody>
                    <tr class="warning">
                      <td><strong>Name</strong></td>
                      <td><?php echo $_SESSION["user_name"] ?></td>
                    </tr>
                    <tr class="warning">
                      <td><strong>Email</strong></td>
                      <td><?php echo $_SESSION["user_email"] ?></td>
                    </tr>
                    <tr class="warning">
                      <td><strong>Phone</strong></td>
                      <td><?php echo $_SESSION["user_phone"] ?></td>
                    </tr>
                  </tbody>
                </table>
              </p>
            </div>
            <p>
              <form id="rent-form" class="form form-horizontal" action="_vehicle.php">
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                    <div class="col-sm-12">
                      <input required type="date" name="date" class="form-control" id="date" placeholder="Which Date?">
                    </div>
                  </div>  
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                    <div class="col-sm-12">
                      <input required type="text" name="days" class="form-control" id="location" placeholder="How many days?">
                    </div>
                  </div>  
                </div>
                <div class="col-md-12 col-sm-12">
                  <div class="form-group">
                    <div class="col-sm-12"> 
                      <textarea required class="form-control" name="message" id="message" placeholder="Additional Message" rows="5"></textarea>
                    </div>
                  </div>  
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group"> 
                    <div class="col-sm-12">
                      <button type="submit" class="btn btn-success"> Submit </button>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="form-group">
                    <div class="col-sm-12">
                      <div class="panel panel-success response-holder" style="padding: 0.2em;"></div>
                    </div>
                  </div>
                </div>
              </form>
            </p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  </body>
  </html>